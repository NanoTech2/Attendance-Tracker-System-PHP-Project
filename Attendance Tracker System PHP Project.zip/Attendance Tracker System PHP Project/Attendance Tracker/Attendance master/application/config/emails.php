<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$config['support_email'] = 'nayak.s.ramesh@gmail.com';
//$config['support_email'] = 'support@attendance.t15.org';
