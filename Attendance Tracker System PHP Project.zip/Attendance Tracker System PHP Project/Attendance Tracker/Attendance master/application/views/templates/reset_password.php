
Hello<br/>
<br/>
You have requested to reset your password.<br />
To reset your password please click <a href="<?= $link ?>">here</a>.<br/>
<br/>
Best Regards,<br/>


